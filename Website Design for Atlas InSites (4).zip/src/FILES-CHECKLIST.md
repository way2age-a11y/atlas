# 📦 Files You Need to Upload to GitHub

Make sure ALL of these files are uploaded:

---

## ✅ **Required Files** (Must have!)

### Root Files
- [ ] `index.html`
- [ ] `package.json`
- [ ] `vite.config.ts`
- [ ] `tsconfig.json`
- [ ] `tsconfig.node.json`
- [ ] `App.tsx`
- [ ] `README.md`

### /src Folder
- [ ] `src/main.tsx`

### /styles Folder
- [ ] `styles/globals.css`

### /components Folder
- [ ] `components/Contact.tsx`
- [ ] `components/ContactPage.tsx` ⚠️ (Make sure this has your Web3Forms key!)
- [ ] `components/Footer.tsx`
- [ ] `components/Header.tsx`
- [ ] `components/Home.tsx`
- [ ] `components/HowItWorks.tsx`
- [ ] `components/HowItWorksPage.tsx`
- [ ] `components/Pricing.tsx`
- [ ] `components/PricingPage.tsx`
- [ ] `components/Solutions.tsx`
- [ ] `components/SolutionsPage.tsx`

### /components/figma Folder
- [ ] `components/figma/ImageWithFallback.tsx`

### /components/ui Folder (All 40 files)
- [ ] `components/ui/accordion.tsx`
- [ ] `components/ui/alert-dialog.tsx`
- [ ] `components/ui/alert.tsx`
- [ ] `components/ui/aspect-ratio.tsx`
- [ ] `components/ui/avatar.tsx`
- [ ] `components/ui/badge.tsx`
- [ ] `components/ui/breadcrumb.tsx`
- [ ] `components/ui/button.tsx`
- [ ] `components/ui/calendar.tsx`
- [ ] `components/ui/card.tsx`
- [ ] `components/ui/carousel.tsx`
- [ ] `components/ui/chart.tsx`
- [ ] `components/ui/checkbox.tsx`
- [ ] `components/ui/collapsible.tsx`
- [ ] `components/ui/command.tsx`
- [ ] `components/ui/context-menu.tsx`
- [ ] `components/ui/dialog.tsx`
- [ ] `components/ui/drawer.tsx`
- [ ] `components/ui/dropdown-menu.tsx`
- [ ] `components/ui/form.tsx`
- [ ] `components/ui/hover-card.tsx`
- [ ] `components/ui/input-otp.tsx`
- [ ] `components/ui/input.tsx`
- [ ] `components/ui/label.tsx`
- [ ] `components/ui/menubar.tsx`
- [ ] `components/ui/navigation-menu.tsx`
- [ ] `components/ui/pagination.tsx`
- [ ] `components/ui/popover.tsx`
- [ ] `components/ui/progress.tsx`
- [ ] `components/ui/radio-group.tsx`
- [ ] `components/ui/resizable.tsx`
- [ ] `components/ui/scroll-area.tsx`
- [ ] `components/ui/select.tsx`
- [ ] `components/ui/separator.tsx`
- [ ] `components/ui/sheet.tsx`
- [ ] `components/ui/sidebar.tsx`
- [ ] `components/ui/skeleton.tsx`
- [ ] `components/ui/slider.tsx`
- [ ] `components/ui/sonner.tsx`
- [ ] `components/ui/switch.tsx`
- [ ] `components/ui/table.tsx`
- [ ] `components/ui/tabs.tsx`
- [ ] `components/ui/textarea.tsx`
- [ ] `components/ui/toggle-group.tsx`
- [ ] `components/ui/toggle.tsx`
- [ ] `components/ui/tooltip.tsx`
- [ ] `components/ui/use-mobile.ts`
- [ ] `components/ui/utils.ts`

---

## 📝 **Optional Files** (Nice to have)

- [ ] `DEPLOYMENT.md` (deployment guide)
- [ ] `STEP-BY-STEP-DEPLOYMENT.md` (detailed walkthrough)
- [ ] `QUICK-START.md` (quick checklist)
- [ ] `Attributions.md` (if you have one)

---

## 🚫 **Don't Upload These** (Not needed)

- ❌ `node_modules/` folder (if you have it)
- ❌ `dist/` folder (if you have it)
- ❌ `.DS_Store` files
- ❌ Any `.zip` files
- ❌ `kajabi-embed.html` (only needed locally)
- ❌ `kajabi-responsive.html` (only needed locally)
- ❌ `standalone.html` (only needed locally)

---

## ⚡ **Quick Upload Method**

### Using GitHub Web Interface:

1. Go to your repository on GitHub
2. Click **"Add file" → "Upload files"**
3. **Drag your ENTIRE project folder** into the browser
4. GitHub will maintain the folder structure automatically
5. Scroll down and click **"Commit changes"**

---

## ✅ **How to Verify**

After uploading, your GitHub repository should show this structure:

```
atlas-insites/
├── components/
│   ├── figma/
│   ├── ui/
│   └── (all .tsx files)
├── src/
│   └── main.tsx
├── styles/
│   └── globals.css
├── App.tsx
├── index.html
├── package.json
├── vite.config.ts
└── tsconfig.json
```

---

**🎯 Pro Tip:** The easiest way is to drag your ENTIRE folder into GitHub's upload page. It will keep all the folders organized automatically!
