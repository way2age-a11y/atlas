# ⚡ Quick Start Checklist

Copy and check off each step as you go!

---

## ☐ **1. Get Web3Forms Key**
- [ ] Go to https://web3forms.com
- [ ] Enter your email
- [ ] Click verification link in email
- [ ] Copy your Access Key

---

## ☐ **2. Add API Key to Code**
- [ ] Open `components/ContactPage.tsx`
- [ ] Find line with `YOUR_WEB3FORMS_ACCESS_KEY_HERE`
- [ ] Replace it with your actual key
- [ ] Save the file

---

## ☐ **3. Create GitHub Account**
- [ ] Go to https://github.com/signup
- [ ] Create free account

---

## ☐ **4. Upload Code to GitHub**
- [ ] Go to https://github.com/new
- [ ] Name it: `atlas-insites`
- [ ] Make it Public
- [ ] Click "Create repository"
- [ ] Click "uploading an existing file"
- [ ] Drag ALL your files into GitHub
- [ ] Click "Commit changes"

---

## ☐ **5. Create Cloudflare Account**
- [ ] Go to https://dash.cloudflare.com/sign-up
- [ ] Create free account
- [ ] Verify email

---

## ☐ **6. Deploy to Cloudflare**
- [ ] Click "Workers & Pages" (left sidebar)
- [ ] Click "Create application"
- [ ] Click "Pages" tab
- [ ] Click "Connect to Git"
- [ ] Connect GitHub account
- [ ] Select `atlas-insites` repository
- [ ] Framework preset: **Vite**
- [ ] Build command: `npm run build`
- [ ] Output directory: `dist`
- [ ] Click "Save and Deploy"

---

## ☐ **7. Wait & Test**
- [ ] Wait 3-5 minutes for build to complete
- [ ] Click your live site URL
- [ ] Test the contact form
- [ ] Check email for form submission

---

## ✅ **Done!**

Your site is live at: `https://YOUR-PROJECT-NAME.pages.dev`

---

## 📚 **Need More Details?**

See **STEP-BY-STEP-DEPLOYMENT.md** for full instructions with screenshots explanations.

---

## 🆘 **Stuck?**

Most common issues:

1. **Build failed?** → Make sure you uploaded ALL files to GitHub
2. **Form not working?** → Did you add your Web3Forms key?
3. **Site not loading?** → Wait 10 minutes and clear browser cache

---

**Estimated time: 20-30 minutes** ⏱️
