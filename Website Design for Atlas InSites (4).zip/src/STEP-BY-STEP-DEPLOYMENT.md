# 🚀 Step-by-Step Deployment Guide for Atlas InSites

## What You'll Need
- ✅ A GitHub account (free at github.com)
- ✅ A Cloudflare account (free at cloudflare.com)
- ✅ Your Atlas InSites code from Figma Make
- ✅ 20-30 minutes

---

## 📋 PART 1: Get Your Code Ready

### Step 1: Download Your Code from Figma Make

1. Click **"Export"** or **"Download"** in Figma Make
2. You'll get a `.zip` file with all your code
3. Unzip it to a folder on your computer (e.g., `atlas-insites`)

---

## 📋 PART 2: Set Up Web3Forms (Contact Form)

### Step 2: Get Your Free Web3Forms API Key

1. Go to **https://web3forms.com**
2. Enter your email address in the box
3. Click **"Get Access Key"**
4. Check your email and click the verification link
5. **Copy your Access Key** (looks like: `a1b2c3d4-1234-5678-90ab-cdef12345678`)

### Step 3: Add the API Key to Your Code

1. Open your code folder (`atlas-insites`)
2. Navigate to: `components/ContactPage.tsx`
3. Find this line (around line 195):
   ```tsx
   <input type="hidden" name="access_key" value="YOUR_WEB3FORMS_ACCESS_KEY_HERE" />
   ```
4. Replace `YOUR_WEB3FORMS_ACCESS_KEY_HERE` with your actual key:
   ```tsx
   <input type="hidden" name="access_key" value="a1b2c3d4-1234-5678-90ab-cdef12345678" />
   ```
5. **Save the file**

---

## 📋 PART 3: Upload to GitHub

### Step 4: Create a GitHub Repository

1. Go to **https://github.com** and sign in
2. Click the **"+"** icon (top right) → **"New repository"**
3. Repository name: `atlas-insites`
4. Description: `Atlas InSites website`
5. Make it **Public** (required for free Cloudflare deployment)
6. **DO NOT** check "Add a README file"
7. Click **"Create repository"**

### Step 5: Upload Your Code to GitHub

**Option A: Using GitHub's Web Interface (Easiest)**

1. On your new repository page, click **"uploading an existing file"**
2. Drag and drop ALL files from your `atlas-insites` folder
   - Including: `App.tsx`, `components/`, `styles/`, `index.html`, `package.json`, etc.
   - Make sure you upload the ENTIRE folder structure
3. Add a commit message: `Initial commit`
4. Click **"Commit changes"**

**Option B: Using GitHub Desktop (Recommended for Future Updates)**

1. Download **GitHub Desktop** from https://desktop.github.com
2. Install and sign in with your GitHub account
3. Click **"Add" → "Add Existing Repository"**
4. Select your `atlas-insites` folder
5. Click **"Publish repository"**
6. Uncheck "Keep this code private"
7. Click **"Publish repository"**

---

## 📋 PART 4: Deploy to Cloudflare Pages

### Step 6: Create a Cloudflare Account

1. Go to **https://dash.cloudflare.com/sign-up**
2. Create a free account
3. Verify your email

### Step 7: Connect GitHub to Cloudflare

1. In Cloudflare Dashboard, click **"Workers & Pages"** (left sidebar)
2. Click **"Create application"**
3. Click the **"Pages"** tab
4. Click **"Connect to Git"**
5. Click **"Connect GitHub"**
6. Authorize Cloudflare to access your GitHub
7. Select **"Only select repositories"**
8. Choose your `atlas-insites` repository
9. Click **"Install & Authorize"**

### Step 8: Configure Your Build Settings

1. You'll see your `atlas-insites` repository listed
2. Click **"Begin setup"**
3. Fill in the build settings:
   - **Project name:** `atlas-insites` (or anything you want)
   - **Production branch:** `main` (or `master`)
   - **Framework preset:** Select **"Vite"** from the dropdown
   - **Build command:** `npm run build` (should auto-fill)
   - **Build output directory:** `dist` (should auto-fill)
4. Click **"Save and Deploy"**

### Step 9: Wait for Deployment

1. Cloudflare will start building your site (takes 2-5 minutes)
2. You'll see a build log with progress
3. When it says **"Success! Your site is live!"** → you're done! 🎉

### Step 10: Get Your Live URL

1. Your site will be live at: `https://atlas-insites.pages.dev`
2. Click **"Continue to project"**
3. You'll see your site URL at the top
4. Click it to view your live site!

---

## 📋 PART 5: Test Everything

### Step 11: Test Your Website

✅ Visit your live URL  
✅ Click through all pages (Home, About, How It Works, Solutions, Pricing, Contact)  
✅ Test the mobile menu (resize your browser)  
✅ Submit a test on the Contact form  
✅ Check your email for the form submission  

---

## 📋 PART 6: Embed in Kajabi (Optional)

### Step 12: Add to Kajabi

1. In Kajabi, go to **Website → Pages → Add New Page**
2. Choose **"Code"** page type
3. Paste this code:

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    body, html {
      margin: 0;
      padding: 0;
      overflow-x: hidden;
    }
    iframe {
      width: 100%;
      height: 100vh;
      border: none;
    }
  </style>
</head>
<body>
  <iframe src="https://YOUR-SITE-NAME.pages.dev"></iframe>
</body>
</html>
```

4. Replace `YOUR-SITE-NAME.pages.dev` with your actual Cloudflare URL
5. Save and publish

---

## 🎯 OPTIONAL: Add a Custom Domain

### Step 13: Connect Your Own Domain (like atlasinsites.com)

1. In Cloudflare Pages, go to your project
2. Click **"Custom domains"** tab
3. Click **"Set up a custom domain"**
4. Enter your domain: `atlasinsites.com`
5. Follow the DNS instructions provided
6. Wait 5-30 minutes for DNS to propagate
7. Your site will be live at your custom domain!

---

## ❓ Troubleshooting

### Build Failed?

**Check these common issues:**

1. **Missing files?**
   - Make sure you uploaded ALL files from Figma Make
   - Especially: `package.json`, `vite.config.ts`, `index.html`, `src/main.tsx`

2. **Build command error?**
   - Double-check build settings in Cloudflare:
     - Build command: `npm run build`
     - Output directory: `dist`
     - Framework preset: `Vite`

3. **Dependencies error?**
   - Make sure `package.json` was uploaded correctly

### Contact Form Not Working?

1. Check that you added your Web3Forms API key to `ContactPage.tsx`
2. Make sure you saved the file before uploading to GitHub
3. Try submitting the form again
4. Check your spam folder for the email

### Site Not Loading?

1. Wait 5-10 minutes after deployment
2. Clear your browser cache (Ctrl+Shift+R or Cmd+Shift+R)
3. Try opening in an incognito/private window

---

## 🎉 You're Done!

Your site should now be:
✅ Live on Cloudflare Pages  
✅ Contact form working  
✅ Fully responsive  
✅ Accessible  
✅ Ready to embed in Kajabi  

---

## 🔄 Making Updates Later

When you want to update your site:

1. Edit files in your local folder
2. Upload changes to GitHub (using GitHub Desktop or web interface)
3. Cloudflare will **automatically rebuild and deploy** (takes 2-3 minutes)
4. Your changes will be live!

---

## 📞 Need Help?

- **Web3Forms issues:** https://web3forms.com/help
- **Cloudflare Pages docs:** https://developers.cloudflare.com/pages
- **GitHub help:** https://docs.github.com

---

**You've got this! 🚀**
