# Atlas InSites - Deployment Guide

## 🚀 Deploy to Cloudflare Pages

### Option 1: Via GitHub (Recommended)

1. **Create a GitHub repository** and push your code:
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git remote add origin YOUR_GITHUB_REPO_URL
   git push -u origin main
   ```

2. **Connect to Cloudflare Pages:**
   - Go to [Cloudflare Dashboard](https://dash.cloudflare.com/)
   - Navigate to **Pages** → **Create a project**
   - Click **Connect to Git**
   - Select your GitHub repository
   - Configure build settings:
     - **Build command:** `npm run build`
     - **Build output directory:** `dist`
     - **Root directory:** `/` (leave empty)
     - **Environment variables:** None needed initially

3. **Deploy!**
   - Click **Save and Deploy**
   - Your site will be live in 2-3 minutes
   - You'll get a URL like: `https://atlas-insites.pages.dev`

4. **Add Custom Domain (Optional):**
   - In Cloudflare Pages, go to **Custom domains**
   - Add your domain (e.g., `atlasinsites.com`)
   - Follow DNS instructions

---

### Option 2: Direct Upload

1. **Build the project locally:**
   ```bash
   npm install
   npm run build
   ```

2. **Upload to Cloudflare:**
   - Go to [Cloudflare Dashboard](https://dash.cloudflare.com/)
   - Navigate to **Pages** → **Create a project**
   - Click **Upload assets**
   - Drag and drop the entire `dist` folder
   - Click **Deploy**

---

## 📧 Setup Contact Form (Web3Forms)

The contact form is configured to use **Web3Forms** (free email forwarding service).

### Steps to activate:

1. **Get your API key:**
   - Go to [Web3Forms.com](https://web3forms.com/)
   - Enter your email address
   - Verify your email
   - Copy your Access Key

2. **Update the form:**
   - Open `/components/ContactPage.tsx`
   - Find this line:
     ```tsx
     <input type="hidden" name="access_key" value="YOUR_WEB3FORMS_ACCESS_KEY_HERE" />
     ```
   - Replace `YOUR_WEB3FORMS_ACCESS_KEY_HERE` with your actual API key

3. **Redeploy:**
   - Commit and push changes (if using GitHub)
   - OR rebuild and reupload (if direct upload)

4. **Test the form:**
   - Submit a test message
   - Check your email for the submission

---

## 🔧 Environment Variables (if needed)

If you want to keep your Web3Forms API key private:

1. In Cloudflare Pages → **Settings** → **Environment variables**
2. Add: `VITE_WEB3FORMS_KEY` with your API key value
3. Update ContactPage.tsx to use: `import.meta.env.VITE_WEB3FORMS_KEY`

---

## 🌐 Alternative: Deploy to Other Platforms

### Netlify
```bash
Build command: npm run build
Publish directory: dist
```

### Vercel
```bash
Framework Preset: Vite
Build Command: npm run build
Output Directory: dist
```

---

## 📦 What's Included

- ✅ **Fully functional React app** with routing
- ✅ **Responsive design** (mobile, tablet, desktop)
- ✅ **Working contact form** (needs Web3Forms API key)
- ✅ **Zero side padding** for Kajabi embedding
- ✅ **WCAG compliant** accessibility features
- ✅ **SEO optimized** with proper meta tags

---

## 🎯 Post-Deployment Checklist

- [ ] Test all pages (Home, About, How It Works, Solutions, Pricing, Contact)
- [ ] Test navigation (desktop and mobile menu)
- [ ] Submit a test form to verify email delivery
- [ ] Test on mobile devices
- [ ] Check accessibility with screen reader
- [ ] Add custom domain (optional)
- [ ] Set up analytics (Google Analytics, Plausible, etc.)

---

## 💡 Tips

- **Free SSL** is included automatically on Cloudflare
- **Global CDN** means your site loads fast worldwide
- **Automatic deployments** happen when you push to GitHub
- **Preview deployments** for branches let you test changes before going live

---

## 📞 Need Help?

If you run into issues:
1. Check Cloudflare Pages build logs
2. Verify all files are committed to Git
3. Make sure `package.json` dependencies are correct
4. Test the build locally first: `npm run build`

---

**Ready to deploy?** Follow Option 1 for the best experience! 🚀
